// TODO: Implement KanbanBoard
// Extract from monolith Sqwady.jsx and refactor with Tailwind + proper React patterns
// See src/data/constants.js for shared data

export default function KanbanBoard(props) {
  return (
    <div className="flex items-center justify-center h-full text-[var(--t3)]">
      <div className="text-center">
        <div className="text-2xl font-bold mb-2">KanbanBoard</div>
        <div className="text-sm">To be implemented — run Claude Code to build this</div>
      </div>
    </div>
  )
}
