// TODO: Implement CalendarView
// Extract from monolith Sqwady.jsx and refactor with Tailwind + proper React patterns
// See src/data/constants.js for shared data

export default function CalendarView(props) {
  return (
    <div className="flex items-center justify-center h-full text-[var(--t3)]">
      <div className="text-center">
        <div className="text-2xl font-bold mb-2">CalendarView</div>
        <div className="text-sm">To be implemented — run Claude Code to build this</div>
      </div>
    </div>
  )
}
