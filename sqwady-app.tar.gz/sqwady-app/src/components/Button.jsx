export default function Button({ children, onClick, variant = 'primary', small, disabled, style }) {
  const base = 'inline-flex items-center gap-1.5 font-semibold rounded-[10px] transition-all duration-150 cursor-pointer border-none'
  const size = small ? 'px-3.5 py-1.5 text-xs' : 'px-5 py-2.5 text-sm'
  const variants = {
    primary: 'bg-[var(--ac2)] text-white hover:bg-[var(--ac)]',
    ghost: 'bg-transparent text-[var(--t2)] border border-[var(--bd2)] hover:border-[var(--ac)] hover:text-[var(--t)]',
  }

  return (
    <button
      onClick={disabled ? undefined : onClick}
      className={`${base} ${size} ${variants[variant]}`}
      style={{ opacity: disabled ? 0.5 : 1, cursor: disabled ? 'not-allowed' : 'pointer', ...style }}
    >
      {children}
    </button>
  )
}
