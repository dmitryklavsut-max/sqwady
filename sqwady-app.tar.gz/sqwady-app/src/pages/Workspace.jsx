import { useState } from 'react'
import { WORKSPACE_TABS } from '../data/constants'
import ChatPanel from '../components/ChatPanel'
import KanbanBoard from '../components/KanbanBoard'
import RoadmapView from '../components/RoadmapView'
import EconomicsView from '../components/EconomicsView'
import CalendarView from '../components/CalendarView'
import PitchStudio from '../components/PitchStudio'
import WikiView from '../components/WikiView'

export default function Workspace({ project, team }) {
  const [activeTab, setActiveTab] = useState('chat')

  const renderTab = () => {
    switch (activeTab) {
      case 'chat': return <ChatPanel project={project} team={team} />
      case 'kanban': return <KanbanBoard team={team} />
      case 'road': return <RoadmapView />
      case 'econ': return <EconomicsView />
      case 'cal': return <CalendarView team={team} />
      case 'pitch': return <PitchStudio />
      case 'wiki': return <WikiView />
      default: return null
    }
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[var(--bd)]"
        style={{ background: 'var(--bg2)' }}>
        <div className="flex items-center gap-3">
          <span className="text-sm font-extrabold tracking-tight"
            style={{
              background: 'linear-gradient(135deg, #818cf8, #a78bfa)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}>
            Sqwady
          </span>
          <span className="text-xs text-[var(--t3)]">·</span>
          <span className="text-xs font-semibold text-[var(--t2)]">{project.name}</span>
        </div>

        {/* Tabs */}
        <div className="flex gap-0.5 bg-[var(--bg3)] rounded-lg p-0.5 overflow-auto">
          {WORKSPACE_TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="px-2.5 py-1 border-none rounded-md cursor-pointer text-[10px] font-semibold whitespace-nowrap"
              style={{
                fontFamily: 'inherit',
                background: activeTab === tab.id ? 'var(--ac2)' : 'transparent',
                color: activeTab === tab.id ? '#fff' : 'var(--t3)',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <span className="text-[10px] text-[var(--t3)]">{team.length} чел</span>
      </div>

      {/* Active module */}
      <div className="flex-1 flex overflow-hidden">
        {renderTab()}
      </div>
    </div>
  )
}
