// LLM Models
export const MODELS = [
  { id: 'claude-sonnet-4-6', label: 'Sonnet 4.6' },
  { id: 'claude-opus-4-6', label: 'Opus 4.6' },
  { id: 'claude-haiku-4-5', label: 'Haiku 4.5' },
  { id: 'gpt-4o', label: 'GPT-4o' },
  { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro' },
]

// Desk roles (12 types)
export const DESKS = [
  { id: 'ceo', label: 'CEO', icon: '🎯', color: '#6366f1', bio: 'Strategy, sales, fundraising.' },
  { id: 'cto', label: 'CTO', icon: '🧠', color: '#06b6d4', bio: 'Architecture, ML, tech leadership.' },
  { id: 'back', label: 'Backend', icon: '⚡', color: '#8b5cf6', bio: 'APIs, distributed systems.' },
  { id: 'front', label: 'Frontend', icon: '🎨', color: '#f59e0b', bio: 'React, UI/UX, design systems.' },
  { id: 'mob', label: 'Mobile', icon: '📱', color: '#3b82f6', bio: 'iOS/Android development.' },
  { id: 'ml', label: 'ML Eng', icon: '🤖', color: '#10b981', bio: 'NLP, embeddings, eval.' },
  { id: 'ops', label: 'DevOps', icon: '🛡', color: '#ef4444', bio: 'K8s, CI/CD, security.' },
  { id: 'des', label: 'Designer', icon: '✨', color: '#ec4899', bio: 'Figma, prototyping.' },
  { id: 'mrk', label: 'Marketer', icon: '📈', color: '#14b8a6', bio: 'SEO, ads, growth.' },
  { id: 'wr', label: 'Writer', icon: '✏️', color: '#a855f7', bio: 'Content, docs.' },
  { id: 'pm', label: 'PM', icon: '📋', color: '#f97316', bio: 'Roadmap, priorities.' },
  { id: 'qa', label: 'QA', icon: '🔍', color: '#84cc16', bio: 'Testing, quality.' },
]

// People avatars
export const PEOPLE = [
  { id: 'm1', avatar: '👨‍💼' },
  { id: 'm2', avatar: '👨‍💻' },
  { id: 'm3', avatar: '🧑‍💼' },
  { id: 'w1', avatar: '👩‍💼' },
  { id: 'w2', avatar: '👩‍💻' },
  { id: 'w3', avatar: '🧑‍💻' },
]

// Chat channels
export const CHANNELS = {
  general: { name: 'General', icon: '💬' },
  eng: { name: 'Engineering', icon: '⚙️' },
  prod: { name: 'Product', icon: '📊' },
  stand: { name: 'Standup', icon: '📋' },
}

// Kanban columns
export const KANBAN_COLS = ['backlog', 'todo', 'in_progress', 'review', 'done']
export const KANBAN_NAMES = {
  backlog: 'Backlog', todo: 'To Do', in_progress: 'In Progress', review: 'Review', done: 'Done',
}
export const KANBAN_COLORS = {
  backlog: '#64748b', todo: '#6366f1', in_progress: '#f59e0b', review: '#a855f7', done: '#10b981',
}
export const PRIORITY_COLORS = { P0: '#ef4444', P1: '#f59e0b', P2: '#6366f1', P3: '#94a3b8' }

// Roadmap phases
export const ROADMAP = [
  { id: 'r1', phase: 'Phase 1 — MVP', color: '#6366f1', start: 0, duration: 3, items: ['Core proxy', 'Classifier', 'Dashboard v1', '5 beta'] },
  { id: 'r2', phase: 'Phase 2 — Beta', color: '#06b6d4', start: 3, duration: 3, items: ['ML classifier', 'Semantic cache', 'SDK v1', '20 clients'] },
  { id: 'r3', phase: 'Phase 3 — Launch', color: '#10b981', start: 6, duration: 3, items: ['Model cascade', 'Analytics v2', 'Enterprise', '100 clients'] },
  { id: 'r4', phase: 'Phase 4 — Scale', color: '#f59e0b', start: 9, duration: 3, items: ['Multi-region', 'Marketplace', 'Mobile', '500 clients'] },
]

// Economics data
export const ECONOMICS = {
  months: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
  revenue: [0, 0, 2, 5, 12, 26, 40, 65, 95, 130, 170, 220],
  costs: [35, 35, 38, 40, 42, 45, 50, 55, 60, 65, 70, 78],
  users: [0, 50, 150, 400, 800, 1500, 2500, 4000, 6000, 9000, 13000, 18000],
}

// Pitch slides
export const PITCH_SLIDES = [
  { title: 'Проблема', icon: '🔥', text: 'LLM API стоит дорого. 70% запросов не требуют мощных моделей.' },
  { title: 'Решение', icon: '💡', text: 'Intelligent Routing — маршрутизация к оптимальному бэкенду.' },
  { title: 'Рынок', icon: '📊', text: 'TAM $50B+ к 2030. AI agents CAGR 46%.' },
  { title: 'Продукт', icon: '🚀', text: 'Classifier + Cache + Cascade. <30ms, 30-50% savings.' },
  { title: 'Бизнес', icon: '💰', text: 'Usage-based. Free → Pro $49 → Team $149.' },
  { title: 'Traction', icon: '📈', text: 'MVP ready. 5 beta. $26K MRR target.' },
  { title: 'Команда', icon: '👥', text: 'AI-native team built with Sqwady.' },
  { title: 'Ask', icon: '🎯', text: 'Pre-Seed $400K. 12 months runway.' },
]

// Wiki pages
export const WIKI_PAGES = [
  { title: 'Architecture Overview', icon: '🏗', text: 'Classifier → Cache → Cascade → Normalizer\nLatency: <30ms. SLA: 99.9%' },
  { title: 'API Reference', icon: '📖', text: 'POST /v1/route\n{prompt, model?, metadata?}\nOpenAI-compatible response' },
  { title: 'Onboarding', icon: '🚀', text: '1. Sign up → API key\n2. pip install ir-sdk\n3. Replace openai.chat() → ir.chat()\n4. See savings' },
  { title: 'Team Agreements', icon: '🤝', text: 'Standup: daily 09:00\nSprint: 2 weeks\nDeploy: canary → full\nPR review: required' },
]

// Workspace tabs
export const WORKSPACE_TABS = [
  { id: 'chat', label: '💬 Чаты' },
  { id: 'kanban', label: '📋 Kanban' },
  { id: 'road', label: '🗺 Roadmap' },
  { id: 'econ', label: '💰 Экономика' },
  { id: 'cal', label: '📅 Календарь' },
  { id: 'pitch', label: '🎤 Питч' },
  { id: 'wiki', label: '📚 Wiki' },
]

// Helpers
export const timestamp = () => {
  const d = new Date()
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}
